const Tweet = require('../models/tweetModel');

exports.createTweet = async (req, res) => {
  const { content } = req.body;
  const userId = req.user.userId;
  try {
    const tweet = new Tweet({ content, user: userId });
    await tweet.save();
    res.status(201).json({ message: 'Tweet created successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Error creating tweet' });
  }
};

exports.getTweets = async (req, res) => {
  try {
    const tweets = await Tweet.find().populate('user', 'username').sort({ createdAt: -1 });
    res.json(tweets);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching tweets' });
  }
};