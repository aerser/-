const express = require('express');
const tweetController = require('../controllers/tweetController');
const { authenticate } = require('../middleware/authenticate');

const router = express.Router();

router.post('/', authenticate, tweetController.createTweet);
router.get('/', tweetController.getTweets);

module.exports = router;