import React from 'react';

const Tweet = ({ tweet }) => (
  <div>
    <h3>{tweet.user.username}</h3>
    <p>{tweet.content}</p>
    <small>{new Date(tweet.createdAt).toLocaleString()}</small>
  </div>
);

export default Tweet;