import React from 'react';
import Tweet from './Tweet';

const TweetList = ({ tweets }) => (
  <div>
    {tweets.map(tweet => (
      <Tweet key={tweet._id} tweet={tweet} />
    ))}
  </div>
);

export default TweetList;