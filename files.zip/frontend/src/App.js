import React, { useState, useEffect } from 'react';
import axios from 'axios';
import TweetList from './components/TweetList';
import UserProfile from './components/UserProfile';

const App = () => {
  const [tweets, setTweets] = useState([]);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchTweets = async () => {
      const response = await axios.get('/api/tweets');
      setTweets(response.data);
    };
    fetchTweets();
  }, []);

  return (
    <div>
      <UserProfile user={user} />
      <TweetList tweets={tweets} />
    </div>
  );
};

export default App;